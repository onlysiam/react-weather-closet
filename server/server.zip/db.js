const express = require("express");
const path = require("path");
const mysql = require("mysql");
const cors = require("cors");

require("dotenv").config();

const app = express();

app.use(express.static(__dirname));

app.use(express.json());
app.use(cors());

const bcrypt = require("bcrypt");

const db = mysql.createConnection({
  user: "onlysiam_weathercloset",
  host: "localhost",
  password: process.env.db_password,
  database: "onlysiam_weathercloset",
  // user: "root",
  // host: "localhost",
  // password: "",
  // database: "weathercloset",
});

(async function () {
  const password = "1620141";
  const hashpass = await bcrypt.hash(password, 9);
})();

// app.use(
//   session({
//     secret: process.env.SESSION_SECRET,
//     saveUninitialized: true,
//     resave: false,
//     cookie: {
//       httpOnly: true,
//       maxAge: parseInt(process.env.SESSION_MAX_AGE),
//     },
//   })
// );

// app.use((req, res) => {
//   console.log(req.session);
// });

app.post("/api/register", (req, res) => {
  const username = req.body.username;
  db.query(
    "INSERT INTO session (username) VALUES (?)",
    [username],
    (err, result) => {
      if (err) {
        res.send({ err: err });
      }
      if (result) {
        res.send(result);
      }
    }
  );
});

app.post("/api/login", (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  db.query(
    "SELECT * FROM user WHERE username = ? AND password = ?",
    [username, password],
    (err, result) => {
      if (err) {
        res.send({ err: err });
      }
      if (result.length > 0) {
        res.send(result);
      } else {
        res.send({ message: "Incorrect Password" });
      }
    }
  );
});

app.post("/api/qrlogin", (req, res) => {
  const bcrypt = require("bcrypt");
  const password = req.body.password;

  db.query(
    "SELECT * FROM user WHERE username = ?",
    [password],
    (err, result) => {
      if (err) {
        res.send({ err: err });
      }
      if (result.length > 0) {
        (async function () {
          const isMatch = await bcrypt.compare(password, result[0].qrid);
          if (isMatch) {
            res.send(result);
          }
        })();
      } else {
        res.send({ message: "Incorrect Qr Code" });
      }
    }
  );
});

app.post("/api/fetch", (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  db.query(
    "SELECT * FROM user INNER JOIN userinfo ON user.username = userinfo.username WHERE user.username = ? AND user.password = ?",
    [username, password],
    "SELECT * FROM user WHERE username = ?",
    [username],
    (err, result) => {
      if (err) {
        res.send({ err: err });
      }
      if (result.length > 0) {
        res.send(result);
      } else {
        res.send({ message: "Cannot Fetch Data" });
      }
    }
  );
});
app.post("/api/userdata", (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  db.query(
    "SELECT * FROM userinfo WHERE username = ?",
    [username],
    (err, result) => {
      if (err) {
        res.send({ err: err });
      }
      if (result.length > 0) {
        res.send(result);
      } else {
        res.send({ message: "Cannot Fetch Data" });
      }
    }
  );
});
app.post("/api/coursedata", (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  db.query(
    "SELECT * FROM courseinfo WHERE username = ?",
    [username],
    (err, result) => {
      if (err) {
        res.send({ err: err });
      }
      if (result.length > 0) {
        res.send(result);
      } else {
        res.send({ message: "Cannot Fetch Data" });
      }
    }
  );
});
app.get("*", (req, res) => {
  res.sendFile(path.resolve(__dirname, "index.html"));
});

// app.listen();
app.listen();
